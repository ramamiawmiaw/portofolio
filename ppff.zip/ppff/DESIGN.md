---
name: Kinetic Engineering
colors:
  surface: '#101415'
  surface-dim: '#101415'
  surface-bright: '#363a3b'
  surface-container-lowest: '#0b0f10'
  surface-container-low: '#191c1e'
  surface-container: '#1d2022'
  surface-container-high: '#272a2c'
  surface-container-highest: '#323537'
  on-surface: '#e0e3e5'
  on-surface-variant: '#bec8d2'
  inverse-surface: '#e0e3e5'
  inverse-on-surface: '#2d3133'
  outline: '#88929b'
  outline-variant: '#3e4850'
  surface-tint: '#89ceff'
  primary: '#89ceff'
  on-primary: '#00344d'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#006591'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#bec6e0'
  on-tertiary: '#283044'
  tertiary-container: '#939bb3'
  on-tertiary-container: '#2b3347'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#101415'
  on-background: '#e0e3e5'
  surface-variant: '#323537'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  code-label:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base-unit: 8px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 80px
  section-gap: 120px
---

## Brand & Style

This design system is engineered for a high-school software developer (RPL), balancing academic rigor with technical forward-thinking. The personality is **Professional, Technical, and Kinetic**. It aims to evoke a sense of reliability and modern craftsmanship, positioning the student as a serious candidate for internships and collaborations.

The visual style is **Corporate / Modern** with a lean toward **Minimalism**. It utilizes expansive white space (or deep dark space), crisp edges, and a restrained but high-impact color application to ensure the user's focus remains on the code and the logic behind the projects.

## Colors

The palette is anchored in a professional **Dark Mode** foundation. 
- **Primary (Electric Blue):** Used for critical calls-to-action, active states, and highlighting key technical achievements.
- **Secondary (Slate Gray):** Utilized for supporting text and non-primary UI elements to reduce visual noise.
- **Tertiary (Deep Navy):** The core background color, providing a stable, "IDE-inspired" canvas.
- **Neutral (Ghost White):** Reserved for primary headings and body copy to ensure maximum readability and contrast.

## Typography

The system utilizes **Inter** for its systematic, utilitarian clarity across all UI and prose. For technical labels, tags, and code snippets, **JetBrains Mono** is introduced to reinforce the Software Engineering (RPL) focus. 

Headlines should use tight letter-spacing to appear more impactful and "engineered." Large display sizes must scale down significantly on mobile to maintain hierarchy without breaking the layout.

## Layout & Spacing

The design system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. 
- **Rhythm:** All spacing is derived from an 8px base unit.
- **Sectioning:** Large vertical gaps (120px+) separate major content areas (About, Skills, Projects) to give the portfolio an editorial feel.
- **Safe Zones:** Use 80px horizontal margins on desktop to prevent content from stretching across ultra-wide monitors, maintaining a comfortable reading line length.

## Elevation & Depth

This design system uses **Tonal Layers** rather than heavy shadows to maintain a clean, flat, technical aesthetic. 
- **Surface 0 (Background):** The deepest navy (#0F172A).
- **Surface 1 (Cards/Nav):** A slightly lighter shade of navy/slate to indicate interactivity or containment.
- **Interactivity:** On hover, elements should use a subtle **Low-contrast outline** (1px solid Electric Blue at 30% opacity) rather than a shadow. This mimics the "focus" state of a code editor.
- **Glassmorphism:** Use a light backdrop blur (8px) on the navigation bar to maintain context while scrolling through content.

## Shapes

The shape language is **Soft** but disciplined. 
- Use `0.25rem` (4px) for small components like checkboxes and input fields.
- Use `0.5rem` (8px) for cards and primary buttons.
- Avoid pill-shaped elements; maintain a rectangular structure to echo the block-based nature of programming and code structures.

## Components

- **Navigation Bar:** Fixed at the top, utilizing a backdrop blur. Use `code-label` typography for nav links. Include a "Resume" button with a primary stroke weight of 1px.
- **Hero Section:** Centered or split-layout. The `display-lg` headline should be the strongest element. Include a secondary sub-headline in Slate Gray to describe the RPL specialization.
- **Project Cards:** Surfaces using "Surface 1" color. Include a language/tech stack chip at the bottom using `code-label` typography and the Electric Blue accent.
- **Skill Chips:** Minimalist tags with a subtle secondary border and no background fill.
- **Buttons:** Primary buttons are solid Electric Blue with Ghost White text. Secondary buttons are outlined. All buttons use 8px roundedness and a transition speed of 200ms.
- **Input Fields:** Dark background, 1px slate border, shifting to Electric Blue on focus. Labels must be clearly visible above the field using `code-label`.